import ray
from ray import serve
from ray.serve.drivers import DAGDriver
from ray.serve.deployment_graph import InputNode
from typing import Dict, List
from starlette.requests import Request
from ray.serve.deployment_graph import ClassNode
import time
# import sklearn
import joblib
import os

subscription_id = '0e9bace8-7a81-4922-83b5-d995ff706507'
resource_group = 'azureml' 
workspace_name = 'ws01ent'
@serve.deployment(user_config={"model_name": "model1"})
class TestDeploy1:
  def __init__(self):
      
      self.model ="no_model"

      try:
        from azure.identity import ManagedIdentityCredential 
        self.model ="step1"
        from azure.ai.ml import MLClient
        self.model ="step2"

        credential = ManagedIdentityCredential()
        self.model ="step3"

        ml_client = MLClient(credential=credential,subscription_id=subscription_id,resource_group_name=resource_group, workspace_name=workspace_name)
        self.model ="step4"

        model_operations = ml_client.models
        print("return model" , model_operations.get("sklearn-iris", version=1))
        self.model ="step5"

        model_operations.download("sklearn-iris", version=1)
        os.makedirs("sklearn-iris", exist_ok=True)

        self.model = joblib.load("sklearn-iris/model.joblib")
      except:
        pass
  def reconfigure(self, config: Dict):
      self.model_name = config.get("model_name")
  def message(self, message):
      time.sleep(1)
      return "model_name: "+str(self.model)+" sklearn-verion: "+" TestDeploy2: " +message
@serve.deployment(user_config={"model_name": "model2"})
class TestDeploy2:
  def __init__(self):
      
      self.model ="no_model"
      try:
        from azure.identity import ManagedIdentityCredential 
        self.model ="step1"
        from azure.ai.ml import MLClient
        self.model ="step2"

        credential = ManagedIdentityCredential()
        self.model ="step3"

        ml_client = MLClient(credential=credential,subscription_id=subscription_id,resource_group_name=resource_group, workspace_name=workspace_name)
        self.model ="step4"

        model_operations = ml_client.models
        print("return model" , model_operations.get("sklearn-iris", version=1))
        self.model ="step5"

        model_operations.download("sklearn-iris", version=1)
        os.makedirs("sklearn-iris", exist_ok=True)

        self.model = joblib.load("sklearn-iris/model.joblib")
      except:
        pass
  def reconfigure(self, config: Dict):
      self.model_name = config.get("model_name")
  def message(self, message):
      time.sleep(1)
      return "model_name: "+str(self.model)+" sklearn-verion: "+" TestDeploy2: " +message

@serve.deployment(num_replicas=2)
class Dispatcher:
    # def __init__(self, model1, model2, model3, model4, model5, model6, model7, model8):
    def __init__(self, model1: ClassNode, model2: ClassNode):

        self.model1 = model1
        self.model2 = model2
        # self.model3 = model3
        # self.model4 = model4
        # self.model5 = model5
        # self.model6= model6
        # self.model7 = model7
        # self.model8 = model8

    def process(self, message):
        # if "1" in message:
        #     ref = await self.model1.message.remote(message)
        # elif "2" in message: 
        #     ref= await self.model2.message.remote(message)
        # elif "3" in message: 
        #     ref= await self.model3.message.remote(message)
        # elif "4" in message: 
        #     ref= await self.model4.message.remote(message)
        # elif "5" in message: 
        #     ref= await self.model5.message.remote(message)
        # elif "6" in message: 
        #     ref= await self.model6.message.remote(message)
        # elif "7" in message: 
        #     ref= await self.model7.message.remote(message)
        # else: ref= await self.model8.message.remote(message)

        # return await ref
        if "1" in message:
            out_message = ray.get(self.model1.message.remote(message))
        elif "2" in message: 
            out_message = ray.get(self.model2.message.remote(message))

        else: out_message = ray.get(self.model2.message.remote(message))

        return out_message
async def json_resolver(request: Request) -> List:
    return await request.json()


with InputNode() as message:
    # message, amount = query[0], query[1]
    deployment1 = TestDeploy1.bind()
    deployment2 = TestDeploy2.bind()
    # deployment3 = TestDeploy3.bind()
    # deployment4 = TestDeploy4.bind()
    # deployment5 = TestDeploy5.bind()
    # deployment6 = TestDeploy6.bind()
    # deployment7 = TestDeploy7.bind()
    # deployment8 = TestDeploy8.bind()
    dispatcher = Dispatcher.bind(deployment1, deployment2)
    output_message = dispatcher.process.bind(message)

deployment_graph = DAGDriver.bind(output_message, http_adapter=json_resolver)