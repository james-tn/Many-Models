import json
import numpy as np
import pandas as pd
import os

# from ray import serve
import time
import mlflow
# Called when the service is loaded
import time
import requests
from azure.identity import ManagedIdentityCredential 
from azure.ai.ml import MLClient

def init():
    global ws, handle


    subscription_id = '0e9bace8-7a81-4922-83b5-d995ff706507'
    # # Azure Machine Learning resource group NOT the managed resource group
    resource_group = 'azureml' 
    workspace_name = 'ws01ent'

    credential = ManagedIdentityCredential()

    ml_client = MLClient(credential=credential,subscription_id=subscription_id,resource_group_name=resource_group, workspace_name=workspace_name)
    model_operations = ml_client.models
    print("return model" , model_operations.get("sklearn-iris", version=1))
    # try:
    #     msi_auth = MsiAuthentication()
    #     print("MSI is successful")
    # except:
    #     print(" exception getting MSI")

    # ws = Workspace(subscription_id=subscription_id,
    #                 resource_group=resource_group,
    #                 workspace_name=workspace_name,
    #                 auth=msi_auth)


    # print("Found workspace {} at location {}".format(ws.name, ws.location))
# Called when a request is received
def run(raw_data):
        # Get the input data 
    text_input = json.loads(raw_data)['data']
    # output = ray.get(handle.remote(text_input))
    response = requests.post('http://rayservice-sample-serve-svc.default.svc.cluster.local:8000/', json=text_input)

    output = response.text
    return json.dumps({"result":output})
